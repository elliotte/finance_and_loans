$(document).on('page:load ready', function(){
  
  var route = document.location.href
  var endOfRoute = route.slice(-4);
  console.log(endOfRoute);
        
  if (route.indexOf('show_dashboard') > -1) {

  } else {

      data = reportHelper.loadShowPageData()
      graphHelper.drawReportShowCharts(data);
      
  }

})
// END OF REPORTS DOCUMENT ON LOAD JS
;
